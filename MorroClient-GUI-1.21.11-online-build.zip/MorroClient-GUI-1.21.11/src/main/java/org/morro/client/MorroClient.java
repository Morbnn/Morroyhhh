package org.morro.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public final class MorroClient implements ClientModInitializer {
    public static final String MOD_ID = "morroclient";
    public static final List<ModuleState> MODULES = new ArrayList<>();

    private static KeyMapping openGuiKey;
    public static boolean hudEnabled = true;
    public static boolean combatInfoEnabled = true;

    static {
        MODULES.add(new ModuleState("Armor HUD", "Shows armor durability information.", "Render", true, 0));
        MODULES.add(new ModuleState("Potion HUD", "Shows active potion effects.", "Render", true, 0));
        MODULES.add(new ModuleState("Totem Counter", "Shows the number of totems in inventory.", "Render", true, 0));
        MODULES.add(new ModuleState("Keystrokes", "Displays movement and attack key presses.", "Render", false, 0));
        MODULES.add(new ModuleState("FPS Display", "Shows current frames per second.", "Render", true, 0));
        MODULES.add(new ModuleState("Coordinates", "Shows player coordinates.", "Render", true, 0));
        MODULES.add(new ModuleState("Crystal Timer", "A placeholder for a crystal cooldown/timing display.", "Crystal", false, 0));
        MODULES.add(new ModuleState("Explosion Particles", "Visual preference placeholder; does not change server behavior.", "Crystal", false, 0));
        MODULES.add(new ModuleState("Mace Cooldown", "Displays mace-related cooldown information when available.", "Mace", false, 0));
        MODULES.add(new ModuleState("Wind Charge Counter", "Shows wind charges held in inventory.", "Mace", false, 0));
        MODULES.add(new ModuleState("Combat Info", "Shows held item and basic player information.", "Combat", true, 0));
        MODULES.add(new ModuleState("ClickGUI", "Opens this module menu.", "Misc", true, GLFW.GLFW_KEY_RIGHT_SHIFT));
    }

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath(MOD_ID, "controls"));
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.morroclient.open_gui",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.consumeClick()) {
                if (client.screen instanceof MorroClickGui) {
                    client.setScreen(null);
                } else {
                    client.setScreen(new MorroClickGui());
                }
            }
        });

        HudElementRegistry.addLast(
                Identifier.fromNamespaceAndPath(MOD_ID, "main_hud"),
                (graphics, tickCounter) -> {
                    if (!hudEnabled) return;
                    Minecraft client = Minecraft.getInstance();
                    if (client.player == null || client.level == null) return;
                    int x = 6, y = 6;
                    graphics.fill(x - 3, y - 3, x + 150, y + (combatInfoEnabled ? 48 : 16), 0x990B0B12);
                    graphics.fill(x - 3, y - 3, x + 150, y - 1, 0xFFFF343F);
                    graphics.text(client.font, "MORRO CLIENT", x, y, 0xFFFF5555, true);
                    graphics.text(client.font, "FPS: " + client.getFps(), x, y + 12, 0xFFFFFFFF, true);
                    if (combatInfoEnabled) {
                        graphics.text(client.font,
                                "XYZ: " + (int) client.player.getX() + " " +
                                        (int) client.player.getY() + " " + (int) client.player.getZ(),
                                x, y + 24, 0xFFBFC7D5, true);
                        String held = client.player.getMainHandItem().isEmpty()
                                ? "Empty hand"
                                : client.player.getMainHandItem().getHoverName().getString();
                        graphics.text(client.font, "Held: " + held, x, y + 36, 0xFFBFC7D5, true);
                    }
                });
    }
}
