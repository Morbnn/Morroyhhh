package org.morro.client;

public final class ModuleState {
    public final String name;
    public final String description;
    public final String category;
    public boolean enabled;
    public int keyCode;

    public ModuleState(String name, String description, String category, boolean enabled, int keyCode) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.enabled = enabled;
        this.keyCode = keyCode;
    }
}
