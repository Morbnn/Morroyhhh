package org.morro.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

/**
 * Original black-and-red Morro ClickGUI.
 * Module entries are toggles for client-side display/settings placeholders only.
 */
public final class MorroClickGui extends Screen {
    private static final String[] CATEGORIES = {"Combat", "Crystal", "Mace", "Render", "Movement", "Misc"};
    private String selectedCategory = "Combat";
    private String search = "";
    private ModuleState waitingForBind = null;
    private int panelX, panelY, panelW, panelH;
    private int listX, listY, listW, rowH;
    private int visibleRows;
    private int scroll = 0;

    public MorroClickGui() {
        super(Component.literal("Morro Client"));
    }

    @Override
    protected void init() {
        panelW = Math.min(500, this.width - 24);
        panelH = Math.min(300, this.height - 24);
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;
        listX = panelX + 132;
        listY = panelY + 83;
        listW = panelW - 150;
        rowH = 27;
        visibleRows = Math.max(1, (panelH - 105) / rowH);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);
        g.fill(0, 0, width, height, 0x99000000);

        // Window and header
        g.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xFF101015);
        g.fill(panelX, panelY, panelX + panelW, panelY + 3, 0xFFFF303D);
        g.fill(panelX, panelY + 3, panelX + 124, panelY + panelH, 0xFF17171F);
        g.fill(panelX + 124, panelY + 3, panelX + 126, panelY + panelH, 0xFF302027);
        g.text(font, "MORRO", panelX + 14, panelY + 12, 0xFFFF4652, true);
        g.text(font, "CLIENT", panelX + 67, panelY + 12, 0xFFFFFFFF, true);
        g.text(font, "FABRIC 1.21.11", panelX + 14, panelY + 28, 0xFF9B9BA8, false);
        g.fill(panelX + 140, panelY + 10, panelX + panelW - 12, panelY + 31, 0xFF1C1C25);
        g.text(font, "Search: " + (search.isEmpty() ? "type to filter..." : search), panelX + 148, panelY + 17, 0xFFBEBEC8, false);
        g.text(font, selectedCategory.toUpperCase(Locale.ROOT), listX, panelY + 51, 0xFFFF5964, true);
        g.text(font, "Click a module to toggle  |  Right Shift to close", listX, panelY + 65, 0xFF888894, false);

        // Category sidebar
        for (int i = 0; i < CATEGORIES.length; i++) {
            int y = panelY + 52 + i * 29;
            boolean active = selectedCategory.equals(CATEGORIES[i]);
            g.fill(panelX + 8, y - 4, panelX + 116, y + 19, active ? 0xFF4A1C25 : 0x00101010);
            if (active) g.fill(panelX + 8, y - 4, panelX + 11, y + 19, 0xFFFF3947);
            g.text(font, CATEGORIES[i], panelX + 19, y + 3, active ? 0xFFFFFFFF : 0xFFB6B6C0, active);
        }

        List<ModuleState> filtered = MorroClient.MODULES.stream()
                .filter(m -> m.category.equals(selectedCategory))
                .filter(m -> m.name.toLowerCase(Locale.ROOT).contains(search.toLowerCase(Locale.ROOT)))
                .collect(Collectors.toList());

        if (filtered.isEmpty()) {
            g.text(font, "No modules match this search.", listX, listY + 8, 0xFF9B9BA8, false);
        } else {
            int maxScroll = Math.max(0, filtered.size() - visibleRows);
            scroll = Math.min(scroll, maxScroll);
            for (int i = scroll; i < Math.min(filtered.size(), scroll + visibleRows); i++) {
                ModuleState module = filtered.get(i);
                int row = i - scroll;
                int y = listY + row * rowH;
                boolean hover = mouseX >= listX && mouseX <= listX + listW && mouseY >= y && mouseY <= y + 23;
                g.fill(listX, y, listX + listW, y + 23, hover ? 0xFF28212A : 0xFF1C1C24);
                g.fill(listX, y, listX + 2, y + 23, module.enabled ? 0xFFFF3947 : 0xFF393942);
                g.text(font, module.name, listX + 10, y + 4, 0xFFF1F1F5, true);
                g.text(font, "BIND", listX + listW - 79, y + 5, 0xFFB8B8C4, false);
                g.text(font, module.enabled ? "ON" : "OFF", listX + listW - 48, y + 5,
                        module.enabled ? 0xFFFF5964 : 0xFF777782, true);
                g.fill(listX + listW - 26, y + 7, listX + listW - 8, y + 17,
                        module.enabled ? 0xFFFF3947 : 0xFF4B4B55);
                g.fill(module.enabled ? listX + listW - 16 : listX + listW - 25,
                        y + 8, module.enabled ? listX + listW - 9 : listX + listW - 18,
                        y + 16, 0xFFFFFFFF);
            }
        }

        g.text(font, "MORRO CLIENT  •  ORIGINAL OPEN-SOURCE PROJECT", panelX + 12,
                panelY + panelH - 15, 0xFF686875, false);
        if (waitingForBind != null) {
            g.fill(panelX + 125, panelY + panelH - 38, panelX + panelW - 10, panelY + panelH - 20, 0xFF4A1C25);
            g.text(font, "Press a key to bind: " + waitingForBind.name, panelX + 134,
                    panelY + panelH - 33, 0xFFFFFFFF, true);
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x();
        double my = event.y();
        if (waitingForBind != null) {
            waitingForBind.keyCode = -100 - event.button();
            waitingForBind = null;
            return true;
        }
        if (mx >= panelX + 8 && mx <= panelX + 116) {
            for (int i = 0; i < CATEGORIES.length; i++) {
                int y = panelY + 52 + i * 29;
                if (my >= y - 4 && my <= y + 19) {
                    selectedCategory = CATEGORIES[i];
                    scroll = 0;
                    return true;
                }
            }
        }
        List<ModuleState> filtered = MorroClient.MODULES.stream()
                .filter(m -> m.category.equals(selectedCategory))
                .filter(m -> m.name.toLowerCase(Locale.ROOT).contains(search.toLowerCase(Locale.ROOT)))
                .collect(Collectors.toList());
        for (int i = scroll; i < Math.min(filtered.size(), scroll + visibleRows); i++) {
            int y = listY + (i - scroll) * rowH;
            if (mx >= listX && mx <= listX + listW && my >= y && my <= y + 23) {
                ModuleState module = filtered.get(i);
                if (mx >= listX + listW - 86 && mx < listX + listW - 53) {
                    waitingForBind = module;
                    return true;
                }
                module.enabled = !module.enabled;
                if (module.name.equals("ClickGUI")) {
                    Minecraft.getInstance().setScreen(null);
                }
                return true;
            }
        }
        // Click the search strip to clear the current query.
        if (mx >= panelX + 140 && mx <= panelX + panelW - 12 && my >= panelY + 10 && my <= panelY + 31) {
            search = "";
            scroll = 0;
            return true;
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (waitingForBind != null) {
            waitingForBind.keyCode = key;
            waitingForBind = null;
            return true;
        }
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT || key == GLFW.GLFW_KEY_ESCAPE) {
            onClose();
            return true;
        }
        if (key == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) {
            search = search.substring(0, search.length() - 1);
            scroll = 0;
            return true;
        }
        if (key == GLFW.GLFW_KEY_DOWN) {
            scroll++;
            return true;
        }
        if (key == GLFW.GLFW_KEY_UP) {
            scroll = Math.max(0, scroll - 1);
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean charTyped(net.minecraft.client.input.CharacterEvent event) {
        if (waitingForBind != null) return true;
        if (!Character.isISOControl(event.codepoint()) && search.length() < 32) {
            search += Character.toString(event.codepoint());
            scroll = 0;
            return true;
        }
        return super.charTyped(event);
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(null);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
