# Morro Client 0.2.0 — ClickGUI prototype

Original black-and-red GUI prototype for Minecraft Java 1.21.11 + Fabric, intended
for compatibility testing with ZalithLauncher.

## Included

- Right Shift opens/closes the ClickGUI.
- Black/red custom interface.
- Categories: Combat, Crystal, Mace, Render, Movement, Misc.
- Search filter (click the search bar to clear; type while the screen is open).
- Toggleable module entries.
- ClickGUI keybind support scaffold.
- HUD from the earlier prototype remains included.

## Important implementation status

This source project has **not been compiled or tested** in this environment. Minecraft
1.21.11 changed GUI input/render APIs; if the build reports API mismatches, adjust
`MorroClickGui.java` against the exact Fabric 1.21.11 mappings. Module entries are
mostly UI/settings placeholders: toggling them does not implement combat automation.
The keybind capture UI is a scaffold and should be completed with a persisted keybind
registry in a later pass.

## Build

- Install JDK 21 and Gradle.
- Extract the ZIP and run `gradle build`.
- JAR output, if compilation succeeds, is in `build/libs/`.

## Install in ZalithLauncher

Use a Minecraft 1.21.11 Fabric profile, install matching Fabric API, and copy the
built JAR into that profile's `mods` folder. Test only after backing up your profile.

This project is original and does not include Krypton's proprietary code or
anti-cheat bypass features.

## Build online without installing Gradle on Android

1. Create a GitHub account if you do not already have one.
2. Create a **public** repository and upload the contents of this project ZIP (the files inside the `MorroClient-GUI-1.21.11` folder, including `.github`).
3. Open the repository's **Actions** tab and select **Build Morro Client**.
4. Tap **Run workflow** if it has not started automatically, then open the finished run.
5. Under **Artifacts**, download `morroclient-jars`. If the build fails, there will be no JAR artifact; read the error log first.

This workflow automates compilation only. The source has not been verified to compile against Minecraft 1.21.11 yet, and most module toggles are placeholders rather than implemented gameplay features.
